# Genshin Tracker

Run the local web app from this folder:

```powershell
.\.venv\Scripts\python.exe -m pip install fastapi uvicorn
.\.venv\Scripts\python.exe -m uvicorn app_v2:app --reload
```

Open <http://127.0.0.1:8000/>. `genshin_v2.db` holds the catalog, inventory,
goals, cost rules, and material links. Back up this file before making large
sets of changes. The browser saves directly to it.

## Add new game content

Open **Add to Catalog** on the page. A new character needs its name, element,
gem family, boss material, common drop family, local specialty, talent book
family, and weekly boss **material name**. A new weapon needs its name, type,
rarity, ascension material family, common drop family, and elite drop family.
The app creates level 1 progress and, for a weapon, Copy 1. Set their goals
using the normal goal controls afterward.

Existing material families are linked automatically. A family not yet in the
database appears under **Missing Material Families**. Enter its exact material
names in tier order: common drops and talent books have tiers 1–3 and 2–4
respectively; elite drops use tiers 2–4; weapon ascension materials use 2–5.
Until those names are saved, the shopping list excludes the affected entry
and says why. Newly created individual materials start with zero owned.

The `.xlsm` workbook and `import_*.py` / `link_materials.py` files were used
for the initial migration. The running app does not read the workbook.
Do not rerun `link_materials.py` after editing mappings in SQLite: it deletes
the current links and rebuilds them from the old workbook.
