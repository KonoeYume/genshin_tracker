"""Inventory overview and remaining costs to max the owned catalog."""
import sqlite3
from collections import Counter

from character_requirements import calculate as character_requirements
from weapon_requirements import calculate as weapon_requirements
from traveller_requirements import calculate as traveller_requirements
from shopping_list import build

CATEGORIES = [
    ('currency', 'Mora'), ('character_exp', 'Character EXP Items'),
    ('weapon_exp', 'Weapon EXP Items'), ('talent_book', 'Talent Materials'),
    ('weapon_ascension', 'Weapon Ascension Materials'),
    ('common_drop', 'Common Mob Drops'), ('elite_drop', 'Elite Mob Drops'),
    ('character_boss_drop', 'Boss Drops'),
    ('weekly_boss_drop', 'Weekly Boss Drops'),
    ('local_specialty', 'Local Specialties'), ('ascension_gem', 'Ascension Gems'),
    ('talent_special', 'Crowns and Special Talent Materials'),
]
EXP_VALUES = {
    "Wanderer's Advice": 1000, "Adventurer's Experience": 5000,
    "Hero's Wit": 20000, 'Enhancement Ore': 400,
    'Fine Enhancement Ore': 2000, 'Mystic Enhancement Ore': 10000,
}


def max_remaining(db):
    """Calculate from current progress to max in a private in-memory snapshot.

    The real database, its targets, and additional weapon copies are untouched.
    """
    temp = sqlite3.connect(':memory:')
    try:
        db.backup(temp)
        temp.row_factory = sqlite3.Row
        temp.execute('UPDATE character_progress SET target_level=90,target_ascension=6')
        temp.execute('UPDATE talent_progress SET target_level=10')
        temp.execute('''UPDATE weapon_copies SET target_level=(CASE WHEN
            (SELECT rarity FROM weapons WHERE id=weapon_id)<=2 THEN 70 ELSE 90 END),
            target_ascension=(CASE WHEN
            (SELECT rarity FROM weapons WHERE id=weapon_id)<=2 THEN 4 ELSE 6 END)''')
        temp.execute('UPDATE traveller_progress SET target_level=90,target_ascension=6')
        temp.execute("UPDATE traveller_talent_progress SET target_level=10 WHERE element!='Cryo'")
        totals = Counter()
        excluded = []
        character_exp = weapon_exp = 0
        count = Counter()
        for cid, name in temp.execute('SELECT id,name FROM characters ORDER BY name').fetchall():
            try:
                _, _, exp, _, items = character_requirements(temp, name)
            except (ValueError, sqlite3.Error) as error:
                excluded.append(f'Character {name}: {error}')
                continue
            count['characters'] += 1
            character_exp += exp
            for material, required, _, _ in items:
                totals[material] += required
        copies = temp.execute('''SELECT wc.id,w.name FROM weapon_copies wc
            JOIN weapons w ON w.id=wc.weapon_id WHERE wc.copy_number=1
            ORDER BY w.name''').fetchall()
        for copy_id, name in copies:
            try:
                _, exp, _, items = weapon_requirements(temp, name, copy_id)
            except (ValueError, sqlite3.Error) as error:
                excluded.append(f'Weapon {name}: {error}')
                continue
            count['first weapon copies'] += 1
            weapon_exp += exp
            for material, required, _, _ in items:
                totals[material] += required
        try:
            _, _, exp, _, items = traveller_requirements(temp)
        except (ValueError, sqlite3.Error) as error:
            excluded.append(f'Traveller: {error}')
        else:
            count['Traveller'] = 1
            character_exp += exp
            for material, required, _, _ in items:
                totals[material] += required
        return totals, character_exp, weapon_exp, dict(count), excluded
    finally:
        temp.close()


def overview(db):
    goals, _, included, goal_excluded, character_exp, weapon_exp = build(db)
    maximum, max_character_exp, max_weapon_exp, max_included, max_excluded = max_remaining(db)
    db.row_factory = sqlite3.Row
    sections = {category: {'category':category,'title':title,'materials':[]}
                for category,title in CATEGORIES}
    sections['other'] = {'category':'other','title':'Other Materials','materials':[]}
    owned_exp = {'character':0,'weapon':0}
    for row in db.execute('''SELECT m.name,m.category,COALESCE(i.quantity,0) owned
        FROM materials m LEFT JOIN inventory i ON i.material_id=m.id ORDER BY m.name'''):
        name, category, owned = row
        goal, ceiling = goals[name], maximum[name]
        material = {'name':name,'owned':owned,'required':goal,
                    'still_needed':max(0,goal-owned),'max_required':ceiling,
                    'max_still_needed':max(0,ceiling-owned)}
        if name in EXP_VALUES:
            material['exp_each'] = EXP_VALUES[name]
            kind = 'character' if category == 'character_exp' else 'weapon'
            owned_exp[kind] += owned * EXP_VALUES[name]
        sections.get(category,sections['other'])['materials'].append(material)
    return {'sections':[section for section in sections.values() if section['materials']],
            'experience':{
                'character':{'required':character_exp,'owned':owned_exp['character'],
                             'max_required':max_character_exp},
                'weapon':{'required':weapon_exp,'owned':owned_exp['weapon'],
                          'max_required':max_weapon_exp}},
            'goal_included':dict(included),'goal_excluded':goal_excluded,
            'max_included':max_included,'max_excluded':max_excluded,
            'max_note':'Max remaining covers every character, the first copy of each weapon, '
                'Traveller level and available element talents. Cryo Traveller talent costs '
                'are not yet available. Extra weapon copies are excluded.'}


def progress_lists(db):
    db.row_factory=sqlite3.Row
    characters=[]
    for row in db.execute('''SELECT c.id,c.name,c.element,c.talent_book_family,
        c.weekly_boss_material,p.current_level,p.target_level,
        p.current_ascension,p.target_ascension FROM characters c
        JOIN character_progress p ON p.character_id=c.id ORDER BY c.name''').fetchall():
        item=dict(row)
        item['talents']=[dict(t) for t in db.execute('''SELECT talent_slot,current_level,target_level
            FROM talent_progress WHERE character_id=? ORDER BY talent_slot''',(row['id'],))]
        characters.append(item)
    weapons=[dict(row) for row in db.execute('''SELECT wc.id,w.name,w.weapon_type,w.rarity,
        w.ascension_family,w.common_drop_family,w.elite_drop_family,wc.copy_number,wc.label,
        wc.current_level,wc.target_level,wc.current_ascension,wc.target_ascension
        FROM weapon_copies wc JOIN weapons w ON w.id=wc.weapon_id
        ORDER BY w.name,wc.copy_number''')]
    traveller={'progress':dict(db.execute('SELECT * FROM traveller_progress WHERE id=1').fetchone()),
               'talents':[dict(t) for t in db.execute('''SELECT element,talent_slot,current_level,
                   target_level FROM traveller_talent_progress ORDER BY element,talent_slot''')]}
    return {'characters':characters,'weapons':weapons,'traveller':traveller}
