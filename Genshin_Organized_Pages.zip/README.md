# Genshin Tracker

Run the local web app from this folder:

```powershell
.\.venv\Scripts\python.exe -m pip install fastapi uvicorn
.\.venv\Scripts\python.exe -m uvicorn app_v2:app --reload
```

Open <http://127.0.0.1:8000/>. `genshin_v2.db` holds the catalog, inventory,
goals, cost rules, and material links. Back up this file before making large
sets of changes. The browser saves directly to it.

## Inventory Overview and Progress Lists

Use **Inventory Overview** in the navigation, or open
<http://127.0.0.1:8000/overview>. It shows all catalog materials, including
materials with no inventory, grouped and ordered by the workbook's families.
Mora has the same columns as other materials. Enter a new total in
**Update Value** and save. Character EXP item values are 1,000 / 5,000 /
20,000 points; weapon ores are 400 / 2,000 / 10,000 points. The summary
compares your combined held EXP points with the EXP required by your current
goals. Each EXP item row also shows how many points that item alone supplies
and the remaining points if using only that item type.

**Max Remaining** shows what it would take from current progress to max every
character and the first copy of every weapon. Extra copies are not counted in
this ceiling, although they remain in your normal goal totals. Traveller's
shared level and available element talents are included; Cryo Traveller talent
costs are not defined yet. Any material mapping gaps are listed as exclusions.
The **To Max** number subtracts owned inventory from Max Remaining. Crafting
conversions and EXP item overshoot are not included in these quantities.

Use separate **Characters**, **Weapons**, and **Traveller** pages to see each
progress list. Search characters or weapons and click a name to edit its goals
or current progress. The **Goals** page contains collapsible editors and the
excluded-goals list. Use **Catalog** to add entries and complete missing
material types.

For an existing database, run the lookup migrations before using the catalog
forms. Rerunning them is safe:

```powershell
.\.venv\Scripts\python.exe add_element_gem_lookup.py
.\.venv\Scripts\python.exe add_catalog_type_lookups.py
```

## Add New Game Content

Open **Add to Catalog** on the page. A new character needs its name, element,
boss material, common drop type, local specialty, talent book
type, and weekly boss **type** (for example, `Dvalin 3`). A new weapon needs its name, weapon type,
rarity, ascension material type, common drop type, and elite drop type.
The app creates level 1 progress and, for a weapon, Copy 1. Set their goals
using the normal goal controls afterward.

## Record Progress

In a character, weapon, or Traveller goal, open **Record Current Progress**
after leveling up. Enter the current level and ascension, plus current talent
levels for characters and Traveller, then save. Current values cannot move
backward. If a current value passes its target, the target moves up to match.
The shopping list then recalculates. Updating progress does not automatically
subtract materials from inventory; use the inventory update field to record
the quantities you actually own.

The gem type is determined from the selected element using the
`element_gems` table. This lookup was migrated from the workbook's
**Enemy Drops Table**; the web app does not read the workbook.

The Common Drop and Elite Drop dropdowns follow **Enemy Drops Table** order.
Talent Book and Weekly Boss Type follow **Character Talent Mats** order;
Ascension Material Type follows **Weapon Ascension Mats** order. Weekly boss
types map to one material name. The one-time lookups now live in SQLite;
the running app does not read the workbook. Every catalog field starts blank.
These type dropdowns offer **New Type…** for game content without a saved mapping.

Existing material types are linked automatically. A type not yet in the
database appears under **Missing Material Types**. Enter its exact material
names in tier order: common drops and talent books have tiers 1–3 and 2–4
respectively; elite drops use tiers 2–4; weapon ascension materials use 2–5;
weekly boss types have one material at tier 0.
Until those names are saved, the shopping list excludes the affected entry
and says why. Newly created individual materials start with zero owned.

The `.xlsm` workbook and `import_*.py` / `link_materials.py` files were used
for the initial migration. The running app does not read the workbook.
Do not rerun `link_materials.py` after editing mappings in SQLite: it deletes
the current links and rebuilds them from the old workbook.
