"""Standalone inventory and catalog progress screens."""

STYLE = '''<style>
body{font:15px system-ui,sans-serif;color:#263244;background:#f8fafc;max-width:1250px;margin:25px auto;padding:0 16px}
nav a{margin-right:18px}section{background:white;border:1px solid #d6dfe8;border-radius:8px;padding:16px;margin:20px 0}
.scroll{overflow-x:auto}table{width:100%;border-collapse:collapse;min-width:750px}th,td{border-bottom:1px solid #e2e8ef;padding:8px;text-align:left;white-space:nowrap}
th{background:#eaf0f6;position:sticky;top:0}td.num,th.num{text-align:right}input[type=number]{width:95px;padding:5px}
button{padding:6px 9px;cursor:pointer}.note{color:#526071}.missing{color:#9a3412;font-weight:600}
.table-tools{display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin:12px 0}a{color:#135b8d}
</style>'''


def overview_page():
    return '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Inventory Overview · Genshin Tracker</title>''' + STYLE + '''</head><body>
<nav><a href="/">Inventory Overview</a><a href="/goals">Goals</a><a href="/characters">Characters</a><a href="/weapons">Weapons</a><a href="/traveller">Traveller</a><a href="/catalog">Add data</a></nav>
<h1>Inventory Overview</h1>
<p class="note">Required means your saved goals from current progress. Max Required means the materials needed from current progress to each available maximum for every character and the first copy of each weapon. Counts are for each individual item; crafting conversions are not included.</p>
<section><h2>Experience Summary</h2><div id="experience"></div></section>
<div id="warnings"></div><div id="sections">Loading…</div>
<p id="save-status" role="status"></p>
<script>
const fmt = new Intl.NumberFormat();
const n = x => fmt.format(x);
function cell(row, value, className='') {const td=row.insertCell();td.textContent=value;td.className=className;return td;}
function metric(name, required, owned, maxRequired) {
  const p=document.createElement('p');
  p.textContent=name+': Goal '+n(required)+' | Owned '+n(owned)+' | Still needed '+n(Math.max(0,required-owned))+
    ' | Max Required '+n(maxRequired)+' | To max '+n(Math.max(0,maxRequired-owned));
  return p;
}
async function save(name, input, button) {
  const raw=input.value.trim(), quantity=Number(raw), message=document.getElementById('save-status');
  if (!raw || !Number.isSafeInteger(quantity) || quantity<0) {message.textContent='Enter a whole number of zero or more.';return;}
  button.disabled=true;
  try {
    const response=await fetch('/api/inventory',{method:'PUT',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({material_name:name,quantity})});
    if(!response.ok) throw new Error('Could not save '+name+' (HTTP '+response.status+').');
    await load();message.textContent=name+' saved.';
  } catch(error){message.textContent=error.message;} finally{button.disabled=false;}
}
async function load() {
  const response=await fetch('/api/overview');
  if(!response.ok) throw new Error('Could not load inventory overview.');
  const data=await response.json();
  const experience=document.getElementById('experience');experience.replaceChildren();
  for(const [key,label] of [['character','Character EXP points'],['weapon','Weapon EXP points']]) {
    const exp=data.experience[key];experience.append(metric(label,exp.required,exp.owned,exp.max_required));
  }
  const note=document.createElement('p');note.className='note';note.textContent='EXP points use the workbook values per item. Consuming items can overshoot the exact EXP requirement and increase Mora cost.';experience.append(note);
  const warnings=document.getElementById('warnings');warnings.replaceChildren();
  const p=document.createElement('p');p.className=data.max_complete?'note':'missing';
  p.textContent=data.max_note;warnings.append(p);
  for(const [title,entries] of [['Goals excluded from required totals',data.goal_excluded],['Entries excluded from max totals',data.max_excluded]]) {
    if(!entries.length) continue;
    const details=document.createElement('details');details.open=true;
    const summary=document.createElement('summary');summary.textContent=title+' ('+entries.length+')';details.append(summary);
    const ul=document.createElement('ul');for(const entry of entries){const li=document.createElement('li');li.textContent=entry;ul.append(li);}
    details.append(ul);warnings.append(details);
  }
  const root=document.getElementById('sections');root.replaceChildren();
  for(const section of data.sections) {
    const panel=document.createElement('section');const heading=document.createElement('h2');heading.textContent=section.title;panel.append(heading);
    const isExp=section.category==='character_exp'||section.category==='weapon_exp';
    const exp=isExp ? data.experience[section.category==='character_exp'?'character':'weapon'] : null;
    if(isExp){const p=document.createElement('p');p.className='note';
      p.textContent='Each row compares the EXP held in that item alone with the total requirement. The summary above combines all item types.';panel.append(p);}
    const wrap=document.createElement('div');wrap.className='scroll';const table=document.createElement('table');
    const head=table.createTHead().insertRow();
    const titles=isExp ? ['Item','Items Owned','EXP Held','EXP Required','EXP Remaining','Max EXP Required','EXP To Max','Update Value',''] :
      ['Material','Required','Owned','Still Needed','Max Required','To Max','Update Value',''];
    for(const title of titles) {
      const th=document.createElement('th');th.textContent=title;head.append(th);
    }
    const body=table.createTBody();
    for(const material of section.materials) {
      const row=body.insertRow();
      cell(row,material.name);
      if(isExp){
        cell(row,n(material.owned),'num');cell(row,n(material.exp_held),'num');cell(row,n(exp.required),'num');
        cell(row,n(Math.max(0,exp.required-material.exp_held)),'num');cell(row,n(exp.max_required),'num');
        cell(row,n(Math.max(0,exp.max_required-material.exp_held)),'num');
      } else {
        cell(row,n(material.required),'num');cell(row,n(material.owned),'num');
        const needed=cell(row,n(material.still_needed),'num');if(material.still_needed)needed.classList.add('missing');
        cell(row,n(material.max_required),'num');cell(row,n(material.max_still_needed),'num');
      }
      const input=document.createElement('input');input.type='number';input.min='0';input.step='1';input.setAttribute('aria-label','Update '+material.name);
      cell(row,'').append(input);
      const button=document.createElement('button');button.textContent='Save';cell(row,'').append(button);
      button.addEventListener('click',()=>save(material.name,input,button));
    }
    wrap.append(table);panel.append(wrap);root.append(panel);
  }
}
load().catch(error=>{document.getElementById('sections').textContent=error.message;});
</script></body></html>'''


def progress_page(kind='characters'):
    if kind not in ('characters','weapons','traveller'):
        raise ValueError('Unknown progress list')
    title = {'characters':'Character Progress','weapons':'Weapon Progress',
             'traveller':'Traveller Progress'}[kind]
    return '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>''' + title + ''' · Genshin Tracker</title>''' + STYLE + '''<style>
body.page-characters section:not(.characters),body.page-weapons section:not(.weapons),
body.page-traveller section:not(.traveller){display:none}</style></head><body class="page-''' + kind + '''">
<nav><a href="/">Inventory Overview</a><a href="/goals">Goals</a><a href="/characters">Characters</a><a href="/weapons">Weapons</a><a href="/traveller">Traveller</a><a href="/catalog">Add data</a></nav>
<h1>''' + title + '''</h1><p class="note">Current → target values. Select an entry to edit it on the Goals page.</p>
<section class="characters"><h2>Characters</h2><div class="table-tools"><label>Search characters <input id="character-search" type="search"></label></div>
<div class="scroll"><table><thead><tr><th>Character</th><th>Element</th><th>Talent Type</th><th>Weekly Boss</th><th>Level</th><th>Ascension</th><th>Talent 1</th><th>Talent 2</th><th>Talent 3</th></tr></thead><tbody id="characters"></tbody></table></div></section>
<section class="traveller"><h2>Traveller</h2><p id="traveller-level"></p><div class="scroll"><table><thead><tr><th>Element</th><th>Talent 1</th><th>Talent 2</th><th>Talent 3</th></tr></thead><tbody id="traveller"></tbody></table></div></section>
<section class="weapons"><h2>Weapons</h2><div class="table-tools"><label>Search weapons <input id="weapon-search" type="search"></label></div>
<div class="scroll"><table><thead><tr><th>Weapon</th><th>Rarity</th><th>Type</th><th>Ascension Type</th><th>Common Drop</th><th>Elite Drop</th><th>Level</th><th>Ascension</th></tr></thead><tbody id="weapons"></tbody></table></div></section>
<p id="status" role="status"></p><script>
const range=(current,target)=>current+' → '+target;
function td(row,text){const cell=row.insertCell();cell.textContent=text ?? '—';return cell;}
let data;
function render(){
  const chars=document.getElementById('characters');chars.replaceChildren();
  const charFilter=document.getElementById('character-search').value.toLocaleLowerCase();
  for(const c of data.characters.filter(c=>c.name.toLocaleLowerCase().includes(charFilter))){
    const r=chars.insertRow(), link=document.createElement('a');link.href='/goals?character='+encodeURIComponent(c.id);link.textContent=c.name;td(r,'').append(link);
    td(r,c.element);td(r,c.talent_book_family);td(r,c.weekly_boss_material);
    td(r,range(c.current_level,c.target_level));td(r,range(c.current_ascension,c.target_ascension));
    for(const t of c.talents)td(r,range(t.current_level,t.target_level));
  }
  const weapons=document.getElementById('weapons');weapons.replaceChildren();
  const weaponFilter=document.getElementById('weapon-search').value.toLocaleLowerCase();
  for(const w of data.weapons.filter(w=>(w.name+' '+(w.label||'')).toLocaleLowerCase().includes(weaponFilter))){
    const r=weapons.insertRow(), link=document.createElement('a');link.href='/goals?weapon='+encodeURIComponent(w.id);
    link.textContent=w.name+(w.copy_number>1?' #'+w.copy_number+(w.label?' · '+w.label:''):'');td(r,'').append(link);
    td(r,w.rarity+'★');td(r,w.weapon_type);td(r,w.ascension_family);td(r,w.common_drop_family);td(r,w.elite_drop_family);
    td(r,range(w.current_level,w.target_level));td(r,range(w.current_ascension,w.target_ascension));
  }
}
async function load(){const response=await fetch('/api/progress');if(!response.ok)throw new Error('Could not load progress lists.');
  data=await response.json();render();const p=data.traveller.progress;
  document.getElementById('traveller-level').textContent='Shared level '+range(p.current_level,p.target_level)+
    ' · Ascension '+range(p.current_ascension,p.target_ascension);
  const grouped={};for(const t of data.traveller.talents)(grouped[t.element]??=[]).push(t);
  const body=document.getElementById('traveller');body.replaceChildren();
  for(const [element,talents] of Object.entries(grouped)){
    const r=body.insertRow();td(r,element);for(const t of talents)td(r,range(t.current_level,t.target_level));
  }
}
document.getElementById('character-search').addEventListener('input',()=>data&&render());
document.getElementById('weapon-search').addEventListener('input',()=>data&&render());
load().catch(error=>{document.getElementById('status').textContent=error.message;});
</script></body></html>'''
